package com.pii.pii_back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PiiBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
